/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package configuration;

/**
 *
 * @author zulutheunique
 */
public abstract class SqlPersister implements Persistable {
    
}
