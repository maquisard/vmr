/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package configuration;

import java.lang.reflect.Constructor;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import metadata.DatabaseMetadata;

/**
 *
 * @author Zulutheunique
 */
public class Configuration {

    private static Configuration current = null;
    private ResourceBundle resource = null;
    private Persistable persist = null;
    private DatabaseMetadata metadata = null;

    public Configuration()
    {
        try {
            Class.forName("com.mysql.jdbc.Driver").newInstance();
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException ex) {
            Logger.getLogger(Configuration.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public Persistable getPersist()  
    {
        if(persist == null)
        {
            try
            {
                Class persistclass = Class.forName(this.resource.getString("persist.class"));
                Constructor[] constructors = persistclass.getConstructors();
                if(constructors.length == 0)
                {
                    throw new Exception("The persister wrapper must have at least one constructor");
                }
                persist = (Persistable)constructors[0].newInstance();
            } catch(Exception ex) {
                Logger.getLogger(Configuration.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return persist.getInstance();
    }
    public static Configuration getCurrent()
    {
        if(current == null)
        {
            current = new Configuration();
        }
        return current;
    }
    public void setResource(ResourceBundle resource)
    {
        this.resource = resource;
    }
    
    public ResourceBundle getResource()
    {
        return this.resource;
    }
    
    public Connection createConnection() throws SQLException
    {
        String url = this.resource.getString("connection.url");
        String username = this.resource.getString("connection.username");
        String password = this.resource.getString("connection.password");
        return DriverManager.getConnection(url, username, password);
    }
    
    public String getValue(String key)
    {
        return this.resource.getString(key);
    }
    
    public DatabaseMetadata getMetadata()
    {
        if(metadata == null)
        {
            try {
                metadata = new DatabaseMetadata("", this.createConnection());
            } catch (SQLException ex) {
                Logger.getLogger(Configuration.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return metadata;
    }

}
