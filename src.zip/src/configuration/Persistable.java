/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package configuration;

import core.Entity;
import java.util.List;
import java.util.Map;

/**
 *
 * @author zulutheunique
 */
public interface Persistable {

    public <T extends Entity> T retrieveById(Class<T> classname, String id);
    public void insert(Entity entity);
    public void update(Entity entity);
    public void delete(Entity entity);
    public <T extends Entity> List<T> readList(Class<T> classname, String statement);
    public <X> X read(Class<X> classname, String query);
    public List<Map<String, Object>> fetchMapList(String query);
    public Persistable getInstance();
    
}
