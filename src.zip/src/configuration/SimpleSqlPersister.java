/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package configuration;

import core.Entity;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import net.sf.persist.Persist;

/**
 *
 * @author zulutheunique
 */
public class SimpleSqlPersister extends SqlPersister {

    private Persist persist = null;

    public SimpleSqlPersister() throws Exception
    {
        this.persist = new Persist(Configuration.getCurrent().createConnection());
    }
    
    @Override
    public <T extends Entity> T retrieveById(Class<T> classname, String id) {
        return this.persist.readByPrimaryKey(classname, id);
    }
    
    @Override
    public void insert(Entity entity) {
        this.persist.insert(entity);
    }
    @Override
    public void update(Entity entity) {
        this.persist.update(entity);
    }
    @Override
    public void delete(Entity entity) {
        this.persist.delete(entity);
    }
    @Override
    public <T extends Entity> List<T> readList(Class<T> classname, String statement) {
        return this.persist.readList(classname, statement);
    }
    @Override
    public Persistable getInstance() {
        try {
            if (this.persist == null || this.persist.getConnection().isClosed() || !this.persist.getConnection().isValid(0)) {
                this.persist = new Persist(Configuration.getCurrent().createConnection());
            }
        } catch (Exception ex) {
            Logger.getLogger(SimpleSqlPersister.class.getName()).log(Level.SEVERE, null, ex);
        }
        return this;
    }

    @Override
    public <X> X read(Class<X> classname, String statement) 
    {
        return this.persist.read(classname, statement);
    }
    
    @Override
    public List<Map<String, Object>> fetchMapList(String query)
    {
        return this.persist.readMapList(query);
    }
    
    public Persist getExternalPersister()
    {
        return persist;
    }

}
