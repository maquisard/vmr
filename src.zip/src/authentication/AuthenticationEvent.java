/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package authentication;

import java.util.EventObject;

/**
 *
 * @author El Zede
 */
public class AuthenticationEvent extends EventObject
{
	/**
	 * 
	 */
	private static final long serialVersionUID = -4602834479329759859L;
	private CmsUser user = null;

	/**
	 * the current user.
	 * @param user
	 */
	public AuthenticationEvent(CmsUser user) 
	{
            super(user);
            this.user = user;
	}
	
	
	/**
	 * 
	 * @return the user involved in this authentication event
	 */
	public CmsUser getUser()
	{
            return user;
	}
}
