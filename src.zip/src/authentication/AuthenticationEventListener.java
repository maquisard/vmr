/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package authentication;

import java.util.EventListener;

/**
 *
 * @author El Zede
 */
public interface AuthenticationEventListener extends EventListener
{
	/**
	 * Post Logged in event
	 * @param event
	 */
	public void onLoggedIn(AuthenticationEvent event);
	
	/**
	 * Pre Logged out event
	 * @param event
	 */
	public void onLoggintOut(AuthenticationEvent event);
	
	/**
	 * Post Logged out event
	 */
	public void onLoggedOut();
}
