/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package authentication;

import core.Entity;
import core.FilterNode;
import core.Log;
import core.Query;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import settings.DefaultSettings;

/**
 *
 * @author El Zede
 */
public class Authentication 
{
	private String usernameProperty = DefaultSettings.getCurrent().getValue("authentication.usernameproperty");
	private String entity = DefaultSettings.getCurrent().getValue("authentication.entity");
	private String passwordProperty = DefaultSettings.getCurrent().getValue("authentication.passwordproperty");
	
	private String usernamePropertyValue = "";
	private String passwordPropertyValue = "";
	
	private CmsUser currentUser = null;
	private List<AuthenticationEventListener> listeners = new ArrayList<>();
	
	private static Authentication context = null;
	
	/**
	 * Initialize the authentication. If the previous user has saved his credentials, then
	 * the initialization loads them and attempts to authenticate the user.
	 */
	protected Authentication()
	{
	}

	/**
	 * 
	 * @return The current instance of the Authentication class.
	 */
	public static Authentication getContext()
	{
            if(context == null)
            {
                context = new Authentication();
            }
            return context;
	}
	
	/**
	 * Finds the user with the current credentials in the database.
	 * once the ONE is found, run the post log in event and builds his Component Privilege matrix.
	 * @return true if and only if one user was found. false otherwise
	 */
	public boolean authenticate()
	{				
            Query query = new Query(entity);
            FilterNode usernameFilter = new FilterNode(usernameProperty, getUsernamePropertyValue());
            FilterNode passwordFilter = new FilterNode(passwordProperty, getPasswordPropertyValue());
            query.filter(usernameFilter.and(passwordFilter));

            try
            {
                List<Map<String, Object>> users = query.runToMap();
                if(users.isEmpty() || users.size() > 1) 
                {
                    return false;
                }

                currentUser = (CmsUser)Entity.createFromMap(users.get(0));

                this.logAuthentication();
                this.fireOnLoggedInEvent();

            } catch (Exception ex) {
                Logger.getLogger(Authentication.class.getName()).log(Level.SEVERE, null, ex);
            }

            return true;
	}
	
        public CmsUser findUserByUsername(String username)
        {
            Query query = new Query(entity);
            FilterNode usernameFilter = new FilterNode(usernameProperty, username);
            List<Map<String, Object>> users = query.runToMap();
            if( users.size() == 1)
            {
                return (CmsUser)Entity.createFromMap(users.get(0));            }
            else
            {
                return null;
            }
        }
	
	/**
	 * Create a log record of the user authentication(fired once the authentication is successful)
	 */
	public void logAuthentication()
	{
            Log log = new Log();
            log.setUserid(currentUser.getId() + " - " + currentUser.getEmail());
            log.setAction("Logged in");
            log.setRegarding("Authentication");
            log.save();
	}
	

	/**
	 * Returns the current user. Will return null when the log out event has occurred
	 * @return the current user
	 */
	public CmsUser getCurrentUser()
	{
            return currentUser;
	}
	
	public synchronized void addAuthenticationEventListener(AuthenticationEventListener l)
	{
            listeners.add(l);
	}
	
	public synchronized void removeAuthenticationEventListener(AuthenticationEventListener l)
	{
            listeners.remove(l);
	}
	
	public synchronized void fireOnLoggedInEvent()
	{
            AuthenticationEvent event = new AuthenticationEvent(currentUser);
            for(AuthenticationEventListener listener : listeners)
            {
                listener.onLoggedIn(event);
            }
	}

	public synchronized void fireOnLoggingOutEvent()
	{
            AuthenticationEvent event = new AuthenticationEvent(currentUser);
            for(AuthenticationEventListener listener : listeners)
            {
                listener.onLoggintOut(event);
            }
	}
	
	public synchronized void fireOnLoggedOutEvent()
	{
            for(AuthenticationEventListener listener : listeners)
            {
                listener.onLoggedOut();
            }
	}
	
	/**
	 * Set the current user to null, run the pre and post log out events, and clean the component privilege matrix;
	 */
	public void logOut()
	{
            this.fireOnLoggingOutEvent();
            currentUser = null;
            this.fireOnLoggedOutEvent();
	}


	/**
	 * @return the usernamePropertyValue
	 */
	public String getUsernamePropertyValue() {
		return usernamePropertyValue;
	}


	/**
	 * @param usernamePropertyValue the usernamePropertyValue to set
	 */
	public void setUsernamePropertyValue(String usernamePropertyValue) {
		this.usernamePropertyValue = usernamePropertyValue;
	}


	/**
	 * @return the passwordPropertyValue
	 */
	public String getPasswordPropertyValue() {
		return passwordPropertyValue;
	}


	/**
	 * @param passwordPropertyValue the passwordPropertyValue to set
	 */
	public void setPasswordPropertyValue(String passwordPropertyValue) {
		this.passwordPropertyValue = passwordPropertyValue;
	}

}
