/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package messages;

import core.Entity;
import core.Query;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author El Zede
 */
public class EmailTemplate extends Entity 
{
    private String name;
    private String subject;
    private String content;

    public EmailTemplate() {
    }

    public static EmailTemplate retrieveByName(String name)
    {
        try 
        {
            Query query = new Query("EmailTemplate");
            query.filter("name", name);
            List<EmailTemplate> templates = query.run(EmailTemplate.class);
            if(templates.size() == 1) return templates.get(0);
            
        } catch (Exception ex) {
            Logger.getLogger(EmailTemplate.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

}
