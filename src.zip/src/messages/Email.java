/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package messages;

import core.Log;
import java.text.MessageFormat;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.mail.Message.RecipientType;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import settings.DefaultSettings;

/**
 *
 * @author El Zede
 */
public class Email 
{
    private String[] recipients = new String[0];
    private String message = "";
    private String subject = "";
    
    private String host = DefaultSettings.getCurrent().getValue("message.email.host");
    private int port = Integer.parseInt(DefaultSettings.getCurrent().getValue("message.email.port"));
    private String username = DefaultSettings.getCurrent().getValue("message.email.username");
    private String password = DefaultSettings.getCurrent().getValue("message.email.password");
    private String protocol = DefaultSettings.getCurrent().getValue("message.email.protocol");
    private String authentication = DefaultSettings.getCurrent().getValue("message.email.auth");
    private String sender = DefaultSettings.getCurrent().getValue("message.email.from");;


    public Email(EmailTemplate template, String recipient, Object... content)
    {
        this.recipients = new String[] { recipient };
        this.message = MessageFormat.format(template.getContent(), content);
        this.subject = MessageFormat.format(template.getSubject(), content);
    }

    public Email(EmailTemplate template, String[] recipients, Object... content)
    {
        this.recipients = recipients;
        this.message = MessageFormat.format(template.getContent(), content);
        this.subject = MessageFormat.format(template.getSubject(), content);
    }

    public void Send()
    {
        try
        {
            Properties props = System.getProperties();
            props.put("mail.transport.protocol", protocol);
            props.put("mail.smtps.host", host);
            props.put("mail.smtps.auth", authentication);

            Session session = Session.getDefaultInstance(props);
            Transport transport = session.getTransport();

            MimeMessage content = new MimeMessage(session);

            for(int i = 0; i < this.recipients.length; i++)
            {
                content.addRecipient(RecipientType.TO, new InternetAddress(this.recipients[i]));
            }

            content.setSubject(this.subject);
            content.setContent(this.message, "text/plain");

            transport.connect(host, port, username, password);
            transport.sendMessage(content, content.getRecipients(RecipientType.TO));
            transport.close();
            
            this.logEmailActivity();
        } 
        catch(Exception ex)
        {
            Logger.getLogger(Email.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    private void logEmailActivity()
    {
        Log log = new Log();
        log.setAction("Send email - " + subject);
        log.setUserid(sender);
        log.setRegarding(message);
        log.save();
    }

    /**
     * @return the recipient
     */
    public String[] getRecipients() {
        return recipients;
    }

    /**
     * @param recipient the recipient to set
     */
    public void setRecipients(String[] recipients) {
        this.recipients = recipients;
    }
    
}
