package core;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */



import configuration.Configuration;
import configuration.Persistable;
import configuration.SimpleSqlPersister;
import java.util.*;
import net.sf.persist.TableMapping;

/**
 *
 * @author Zulutheunique
 */
public class Query {

    private String tablename = "";
    private Node root = null;
    private String queryStatement = "";
    private Persistable persist = null;
    private String[] columns = new String[0];
    private List<Join> joins = new ArrayList<>();
    private Map<String, String> orderbys = new HashMap<>();
    private int pagesize = 10;
    private int pageindex = 1;
    private int numberOfPages = -1;
    private boolean paginate = false;
    private int rowIndex = 0;

    public Query(String tablename)
    {
        this.tablename = tablename;
        persist = Configuration.getCurrent().getPersist();
    }
    
    public Query(String tablename, int pagesize)
    {
        this(tablename);
        this.paginate = true;
        this.pagesize = pagesize;
    }
    
    public <T extends Entity> List<T> run(Class<T> classname) 
    {
        columns = ((TableMapping)((SimpleSqlPersister)this.persist).getExternalPersister().getMapping(classname)).getColumns();
        this.getQueryStatement();
        List<T> results = Configuration.getCurrent().getPersist().readList(classname, queryStatement);
        for(int i = 0; i < results.size(); i++)
        {
            results.get(i).persisted = true;
        }
        return results;
    }
    
    
    public int count()
    {
        this.getQueryStatement();
        String countStatement = queryStatement.replace("select * ", "select count(*) ");
        int size = Configuration.getCurrent().getPersist().read(Integer.class, countStatement);
        return size;
    }
    
    public List<Map<String, Object>> runToMap()
    {
        this.getQueryStatement();
        List<Map<String, Object>> results = Configuration.getCurrent().getPersist().fetchMapList(queryStatement);
        for(Map<String, Object> entityMap : results)
        {
            entityMap.put("persisted", true);
            entityMap.put("entityName", tablename);
        }
        return results;
    }
    
    public <T extends Entity> List<T> nextPageResults(Class<T> classname)
    {
        if(!paginate || pageindex >= numberOfPages)
        {
            return new ArrayList<>();
        }
        
        if(numberOfPages < 0)
        {
            int sizeOfAllRecords = this.count();
            numberOfPages =  sizeOfAllRecords / pagesize;
            if(sizeOfAllRecords % pagesize != 0)
            {
                numberOfPages++;
            }
        }
        
        String query = this.getQueryStatement() + String.format(" limit %s,%s", rowIndex, pagesize);
        List<T> results = Configuration.getCurrent().getPersist().readList(classname, query);
        for(int i = 0; i < results.size(); i++)
        {
            results.get(i).persisted = true;
        }
        
        rowIndex += pagesize;
        pageindex++;
        
        return results;
    }
    
    public void filter(Node filter, String operator)
    {
        if(filter != null && (operator.equalsIgnoreCase("and") || operator.equalsIgnoreCase("or")))
        {
            if(filter instanceof FilterNode)
            {
                //((FilterNode)filter).setTablename(tablename); No need for this since I set the table explicitly outside <At least for now>
            }
            if(this.root == null)
            {
                this.root = filter;
            } else {
                if(operator.equalsIgnoreCase("and"))
                {
                    this.root = this.root.and(filter);
                } else {
                    this.root = this.root.or(filter);
                }
            }
        }
    }
    public void filter(String property, Object propertyValue)
    {
        this.filter(property, propertyValue, ConditionOperator.Equal);
    }
    public void filter(String property, Object propertyValue, String conditionOperator)
    {
        this.filter(property, propertyValue, conditionOperator, "And");
    }
    public void filter(String property, Object propertyValue, String conditionOperator, String booleanOperator)
    {
        FilterNode node = new FilterNode(property, propertyValue, conditionOperator);
        node.setTablename(tablename);
        if(this.root == null)
        {
            this.root = node;
        } else {
            if(booleanOperator.equalsIgnoreCase("And"))
            {
                this.root = this.root.and(node);
            } else {
                this.root = this.root.or(node);
            }
        }
    }
    public void filter(Node filter)
    {
        this.filter(filter, "and");
    }

    public void join(String thisproperty, String othertable , String otherproperty)
    {
        this.joins.add(new Join(this.tablename, thisproperty, othertable, otherproperty));
    }

    public void join(Join join)
    {
        if(join != null)
        {
            this.joins.add(join);
        }
    }

    public void orderBy(String property, String direction)
    {
        String dir = OrderBy.ASC;
        if(direction != null && !direction.isEmpty() && (direction.equalsIgnoreCase(OrderBy.ASC) || direction.equalsIgnoreCase(OrderBy.DESC)))
        {
            dir = direction;
        }
        this.orderbys.put(property, dir);
    }

    public String getQueryStatement() {
        //building the columns string
        
        String joinStr = "";
        String joinFilter = "";
        
        for(int i = 0; i < this.joins.size(); i++)
        {
            joinStr += this.joins.get(i).generateStatement();
            FilterNode filter = (FilterNode)this.joins.get(i).getFilter();
            if(filter != null)
            {
                joinFilter += filter.generateStatement() + " And ";
            }
        }

        if(joinFilter.toLowerCase().contains("and"))
        {
            joinFilter = joinFilter.substring(0, joinFilter.toLowerCase().lastIndexOf("and"));
        }

        String orders = "";
        if(this.orderbys.size() > 0)
        {
            orders = "Order By ";
            Iterator iterator = this.orderbys.keySet().iterator();
            while(iterator.hasNext())
            {
                String property = (String)iterator.next();
                String direction = (String)this.orderbys.get(property);
                orders += String.format("%s.%s %s, ", this.tablename, property, direction);
            }
            orders = orders.substring(0, orders.length()-2);
        }
        
        String column_str = "*";
        if(columns.length > 0)
        {
            column_str = String.format("%s.%s", this.tablename, columns[0]);
            for(int i = 1; i < columns.length; i++)
            {
                column_str += ", " + String.format("%s.%s", this.tablename, columns[i]);
            }
        }
        
        if(this.root == null)
        {
            if(joinFilter == null || joinFilter.isEmpty())
            {
                queryStatement = String.format("select %s from %s %s %s", column_str, this.tablename, joinStr, orders);
            } else {
                queryStatement = String.format("select %s from %s %s where %s %s", column_str, this.tablename, joinStr, joinFilter, orders);
            }
        } else {
            queryStatement = String.format("select %s from %s %s where %s %s %s", column_str, this.tablename, joinStr, this.root.generateStatement(), joinFilter, orders);
        }
        return queryStatement;
    }
    

    /**
     * @return the pagesize
     */
    public int getPagesize() {
        return pagesize;
    }

    /**
     * @return the numberOfPages
     */
    public int getNumberOfPages() {
        return numberOfPages;
    }
}
