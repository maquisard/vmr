/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package core;

import java.util.Date;

/**
 *
 * @author El Zede
 * @ CSDL
 */
    @EntityType(value="Log")
    public class LogCrudEventHandler extends CrudEventHandler
    {
        @Override
        public boolean onCreating(Entity entity)
        {
            boolean returnValue = super.onCreating(entity);
            Log log = (Log)entity;
            log.setCreatedon(new Date());
            return returnValue;
        }
    }
