package core;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */



/**
 *
 * @author Zulutheunique
 */
public class Node {
    private Node leftNode = null;
    private Node rightNode = null;
    protected String value = "";

    public Node() {}
    public Node(String value)
    {
        this.value = value;
    }

    public String generateStatement()
    {
        if(value.isEmpty() || value == null)
        {
            throw new NullPointerException("Both Children must not be null.");
        }
        String leftStatement = "";
        String rightStatement = "";
        
        if(this.rightNode != null)
        {
            rightStatement = this.generateStatement(this.rightNode);
        }
        if(this.leftNode != null)
        {
            leftStatement = this.generateStatement(this.leftNode);
        }
        return String.format("(%s %s %s)", leftStatement, value, rightStatement);
    }
    
    protected String generateStatement(Node node)
    {
        if(node instanceof FilterNode)
        {
            return node.generateStatement();
        } else {
            return node.generateStatement();
        }
    }

    public Node and(Node node)
    {
        return this.booleanAppend("and", node);
    }
    public Node or(Node node)
    {
        return this.booleanAppend("or", node);
    }
    private Node booleanAppend(String booleanOperator, Node node)
    {
        Node returnNode = new Node(booleanOperator);
        returnNode.setLeftNode(this);
        returnNode.setRightNode(node);
        return returnNode;
    }

    public String getValue()
    {
        return value;
    }

    /**
     * @return the leftNode
     */
    public Node getLeftNode() {
        return leftNode;
    }

    /**
     * @param leftNode the leftNode to set
     */
    public void setLeftNode(Node leftNode) {
        this.leftNode = leftNode;
    }

    /**
     * @return the rightNode
     */
    public Node getRightNode() {
        return rightNode;
    }

    /**
     * @param rightNode the rightNode to set
     */
    public void setRightNode(Node rightNode) {
        this.rightNode = rightNode;
    }
}
