package core;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */



import configuration.Configuration;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Modifier;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import net.sf.persist.annotations.NoColumn;

/**
 *
 * @author Zulutheunique
 */
public abstract class Entity 
{    
    protected String id;
    protected boolean persisted = false;
    protected CrudEventHandler eventHandler;
    private Map<String, Field> fields = new HashMap<>();
    
    public Entity()
    {
        id = UUID.randomUUID().toString();
        eventHandler = CrudEventHandlerFactory.getFactory().getEventHandler(this.getClass().getSimpleName());
        this.getAllFields();
    }
    
    public Entity(Entity entity)
    {
        if(entity == null || !this.getClass().equals(entity.getClass())) return;

        for(Field field : entity.getClass().getDeclaredFields())
        {
            String propertyName = field.getName();
            Object propertyValue = entity.getPropertyValue(propertyName);
            this.setPropertyValue(propertyName, propertyValue);
        }
        eventHandler = CrudEventHandlerFactory.getFactory().getEventHandler(this.getClass().getSimpleName());
        this.getAllFields();
    }
    
    @NoColumn
    private void getAllFields()
    {
        for(Field field : this.getClass().getDeclaredFields())
        {
            fields.put(field.getName(), field);
        }
        Class parent = this.getClass().getSuperclass();
        while(parent != null)
        {
            for(Field field : parent.getDeclaredFields())
            {
                fields.put(field.getName(), field);
            }
            parent = parent.getSuperclass();
        }
    }
    
    public <T extends Entity> T copy(boolean deep)
    {
        try 
        {
            Constructor defaultConstructor = this.getClass().getConstructors()[0];
            T entity = (T)defaultConstructor.newInstance();
            if(!deep)
            {
                entity.id = id;
            }
            
            for(Field field : this.getClass().getDeclaredFields())
            {
                String propertyName = field.getName();
                Object propertyValue = this.getPropertyValue(propertyName);
                entity.setPropertyValue(propertyName, propertyValue);
            }
            
            return entity;
        } catch (SecurityException | InstantiationException | IllegalAccessException | IllegalArgumentException | InvocationTargetException ex) {
            Logger.getLogger(Entity.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }
    
    public <T extends Entity> T copy()
    {
        return this.copy(false);
    }

    public void save()
    {
        Entity copy = this.copy();
        try
        {
            if(persisted)
            {
                if(eventHandler.onUpdating(this, Entity.retrieveById(this.getClass(), id)))
                {
                    Configuration.getCurrent().getPersist().update(this);
                    eventHandler.onUpdated(copy, this);
                }
            } else {
                if(eventHandler.onCreating(this))
                {
                    Configuration.getCurrent().getPersist().insert(this);
                    persisted = true;
                    eventHandler.onCreated(copy, this);
                }
            }
        } catch (Exception ex) {
            Logger.getLogger(Entity.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
	
	public void delete()
	{
            try
            {
		if(persisted)
                {
                    if(eventHandler.onDeleting(this))
                    {
                        Configuration.getCurrent().getPersist().delete(this);
                        eventHandler.onDeleted(this);
                    }
                }
            } catch(Exception ex) {
                Logger.getLogger(Entity.class.getName()).log(Level.SEVERE, null, ex);
            }
	}
	
	@NoColumn
	public Object getPropertyValue(String propertyName)
	{
            if("id".equals(propertyName)) return id;
            try 
            {
                //Field field = this.getClass().getDeclaredField(propertyName);
                Field field = fields.get(propertyName);
                field.setAccessible(true);
                return field.get(this);

            } catch (SecurityException | IllegalArgumentException | IllegalAccessException ex) {
                Logger.getLogger(Entity.class.getName()).log(Level.SEVERE, null, ex);
            }
            return null;
	}
	
	
	@NoColumn
	public final void setPropertyValue(String propertyName, Object value)
	{
            try 
            {
                if("id".equals(propertyName)) return;
                Field field = fields.get(propertyName);
                //Field field = this.getClass().getDeclaredField(propertyName);
                //ignore constants and static fields...this is more 
                //to ignore the exceptions thrown if the fields are final or static
                if(Modifier.isFinal(field.getModifiers()) || Modifier.isStatic(field.getModifiers())) return;
                field.setAccessible(true);
                field.set(this, value);
            } catch (SecurityException | IllegalArgumentException | IllegalAccessException ex) {
                Logger.getLogger(Entity.class.getName()).log(Level.SEVERE, null, ex);
            }
	}
        
        @NoColumn
        public Field getField(String propertyName)
        {
            try {
                Field field = this.getClass().getDeclaredField(propertyName);
                if(field != null) return field;
                Class parent = this.getClass().getSuperclass();
                while(parent != null)
                {
                    field = parent.getDeclaredField(propertyName);
                    if(field != null) return field;
                    parent = parent.getSuperclass();
                }
            } catch (NoSuchFieldException | SecurityException ex) {
                Logger.getLogger(Entity.class.getName()).log(Level.SEVERE, null, ex);
            }
            return null;
        }
	
	
	/**
	 * Not a very good comparison. It does not really compare two objects; 
	 * it just checks whether two objects point to the same record in the database, which is
	 * a sufficient comparison in many cases.
	 */
	@Override
	public boolean equals(Object entity)
	{
            if(entity == null || !(entity instanceof Entity)) return false;

            Entity other = (Entity)entity;

            return this.id.equals(other.id);
	}

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 47 * hash + Objects.hashCode(this.id);
        hash = 47 * hash + (this.persisted ? 1 : 0);
        return hash;
    }
	
	/**
	 * @return the id
	 */
	public String getId() {
            return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
            this.id = id;
	}
		
	public boolean isPersisted()
	{
            return persisted;
	}
	
	/**
	 * Update the entity properties with the latest values from the database
	 */
	public void refresh()
	{
            Entity entity = Entity.retrieveById(this.getClass(), this.getId());
            if(entity != null)
            {
                for(Field field : entity.getClass().getDeclaredFields())
                {
                    String propertyName = field.getName();
                    Object propertyValue = entity.getPropertyValue(propertyName);
                    this.setPropertyValue(propertyName, propertyValue);
                }
            }
	}
	
        public static <T extends Entity> T createFromMap(Map<String, Object> entityMap)
        {
            if(entityMap ==  null || entityMap.isEmpty()) return null;
            
            String entityName = entityMap.get("entityName").toString();
            try 
            {
                Constructor defaultConstructor = Class.forName(entityName).getConstructors()[0];
                T entity = (T)defaultConstructor.newInstance();
                entity.id = entityMap.get("id").toString();
                boolean persisted = (Boolean)entityMap.get("persisted");
                entity.persisted = persisted;
                for(String propertyName : entityMap.keySet())
                {
                    Object propertyValue = entityMap.get(propertyName);
                    entity.setPropertyValue(propertyName, propertyValue);
                }
                
                return entity;
                
            } catch (ClassNotFoundException | SecurityException | InstantiationException | IllegalAccessException | IllegalArgumentException | InvocationTargetException ex) {
                Logger.getLogger(Entity.class.getName()).log(Level.SEVERE, null, ex);
                return null;
            }
        }
        
	public static <T extends Entity> T retrieveById(Class<T> classname, String id)
	{
            try
            {
                if(id == null || id.isEmpty()) return null;

                T entity = Configuration.getCurrent().getPersist().retrieveById(classname, id);
                if(entity != null)
                {
                    entity.persisted = true;
                    return entity;
                }
                CrudEventHandlerFactory.getFactory().getEventHandler(entity.getClass().getSimpleName()).onRetrieve(entity);
            } catch (Exception ex) {
                Logger.getLogger(Entity.class.getName()).log(Level.SEVERE, null, ex);
            }
            return null;
	}
	
	
	public static <T extends Entity> int countAll(Class<T> classname)
	{
            try
            {
                String query = String.format("select count(*) from %s", classname.getSimpleName());
                return Configuration.getCurrent().getPersist().read(Integer.class, query);
            } catch (Exception ex) {
                Logger.getLogger(Entity.class.getName()).log(Level.SEVERE, null, ex);
            }
            return -1;
	}
		
	public static <T extends Entity> List<T> all(Class<T> classname)
	{
            try 
            {
                Query query = new Query(classname.getSimpleName());
                return query.run(classname);
            } catch (Exception ex) {
                Logger.getLogger(Entity.class.getName()).log(Level.SEVERE, null, ex);
            }
            return new ArrayList<>();
	}
        
	
}
