package core;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */



/**
 *
 * @author zulutheunique
 */
public class OrderBy {
    public static String ASC = "asc";
    public static String DESC = "desc";
}
