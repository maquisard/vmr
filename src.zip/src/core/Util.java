package core;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */



/**
 *
 * @author zulutheunique
 */
public final class Util {
    public static String evaluateNullString(String value)
    {
        if(value == null)
        {
            return "";
        }
        return value.toString();
    }
    public static boolean isStringNullOrEmpty(String value)
    {
        return (value == null || value.isEmpty());
    }

}
