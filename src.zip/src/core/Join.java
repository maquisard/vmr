package core;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */



/**
 *
 * @author zulutheunique
 */
public class Join {
    private String table1;
    private String table2;
    private String property1;
    private String property2;
    private Node root = null;

    public Join(String table1, String property1, String table2, String property2)
    {
        this.table1 = table1;
        this.table2 = table2;
        this.property1 = property1;
        this.property2 = property2;
    }

    public void filter(Node filter, String operator)
    {
        if(filter != null && (operator.equalsIgnoreCase("and") || operator.equalsIgnoreCase("or")))
        {
            if(filter instanceof FilterNode)
            {
                ((FilterNode)filter).setTablename(table2);
            }

            if(this.root == null)
            {
                this.root = filter;
            } else {
                if(operator.equalsIgnoreCase("and"))
                {
                    this.root = this.root.and(filter);
                } else {
                    this.root = this.root.or(filter);
                }
            }
        }
    }

    public void filter(Node filter)
    {
        this.filter(filter, "and");
    }

    public String generateStatement()
    {
        return String.format(" inner join %s on %s.%s = %s.%s ", this.table2, this.table1, this.property1, this.table2, this.property2);
    }

    /**
     * @return the table1
     */
    public String getTable1() {
        return table1;
    }

    /**
     * @param table1 the table1 to set
     */
    public void setTable1(String table1) {
        this.table1 = table1;
    }

    /**
     * @return the table2
     */
    public String getTable2() {
        return table2;
    }

    /**
     * @param table2 the table2 to set
     */
    public void setTable2(String table2) {
        this.table2 = table2;
    }

    /**
     * @return the property1
     */
    public String getProperty1() {
        return property1;
    }

    /**
     * @param property1 the property1 to set
     */
    public void setProperty1(String property1) {
        this.property1 = property1;
    }

    /**
     * @return the property2
     */
    public String getProperty2() {
        return property2;
    }

    /**
     * @param property2 the property2 to set
     */
    public void setProperty2(String property2) {
        this.property2 = property2;
    }

    public Node getFilter()
    {
        return root;
    }

}
