package core;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */



/**
 *
 * @author Zulutheunique
 */
public class ConditionOperator {
    public static String Equal = "=";
    public static String NotEqual = "<>";
    public static String LessThan = "<";
    public static String LessThanOrEqual = "<=";
    public static String GreaterThan = ">";
    public static String GreaterThanOrEqual = ">=";
    public static String Like = "like";
}
