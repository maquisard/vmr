/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package core;

/**
 *
 * @author El Zede
 */
public class CrudEventHandler 
{

    public boolean onCreating(Entity entity)
    {
        return true;
    }
    
    public void onCreated(Entity preImage, Entity postImage)
    {
        
    }
    
    public boolean onUpdating(Entity localImage, Entity serverImage)
    {
        return true;
    }
    
    public void onUpdated(Entity preImage, Entity postImage)
    {
        
    }
    
    public boolean onDeleting(Entity entity)
    {
        return true;
    }
    
    public void onDeleted(Entity entity)
    {
        
    }
    
    public void onRetrieve(Entity entity)
    {
        
    }
    
    
}
