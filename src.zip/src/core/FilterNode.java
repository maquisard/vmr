package core;

import java.util.Date;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */



/**
 *
 * @author Zulutheunique
 */
public class FilterNode extends Node {

    private String propertyname = "";
    private Object propertyvalue = null;
    private String operator = "";
    private String tablename = "";

    public FilterNode(String propertyname, Object propertyvalue)
    {
        this.propertyname = propertyname;
        this.propertyvalue = propertyvalue;
        this.operator = ConditionOperator.Equal;
    }
    public FilterNode(String propertyname, Object propertyvalue, String operator)
    {
        this.propertyname = propertyname;
        this.propertyvalue = propertyvalue;
        this.operator = operator;
    }
    
    @Override
    public String generateStatement()
    {
        this.updateValue();
        return value;
    }
    
    private void updateValue()
    {
        if(this.tablename != null && !this.tablename.isEmpty() && !this.propertyname.contains(tablename + "."))
        {
            this.propertyname = tablename + "." + this.propertyname;
        }
        if(this.propertyvalue instanceof String || this.propertyvalue instanceof Character 
                || this.propertyvalue instanceof Date)
        {
            this.value = String.format("(%s %s '%s')", this.propertyname, this.operator, this.propertyvalue);
        } else {
            this.value = String.format("(%s %s %s)", this.propertyname, this.operator, this.propertyvalue);
        }
    }
    public void setTablename(String tablename)
    {
        this.tablename = tablename;
    }
}
