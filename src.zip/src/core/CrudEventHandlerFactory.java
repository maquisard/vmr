/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package core;

import configuration.Configuration;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.reflections.Reflections;
import settings.DefaultSettings;

/**
 *
 * @author elzede
 */
    public class CrudEventHandlerFactory
    {
        
        private Map<String, CrudEventHandler> crudEventHandlerManager = new HashMap<>();
 
        private static CrudEventHandlerFactory factory = null;
        
        private CrudEventHandlerFactory() 
        {
            Reflections.log = null;
            crudEventHandlerManager.put("core", new CrudEventHandler());
            loadBaseCrudEventHandlers();
        }
        
        public static CrudEventHandlerFactory getFactory()
        {
            if(factory == null)
            {
                factory = new CrudEventHandlerFactory();
            }
            return factory;
        }
        
        public CrudEventHandler getEventHandler(String _classname)
        {
            try 
            {
                String eventHandlerPackageName = Configuration.getCurrent().getValue("eventhandler.package");
                String classname = eventHandlerPackageName + "." + _classname;
                                
                if(crudEventHandlerManager.get(classname) != null) return crudEventHandlerManager.get(classname);
                
                //check if there is a base version of it before proceeding
                if(crudEventHandlerManager.get("core." + _classname) != null) return crudEventHandlerManager.get("core." + _classname);
                
                if(classname == null || classname.isEmpty() || eventHandlerPackageName == null || eventHandlerPackageName.isEmpty())
                    return crudEventHandlerManager.get("core");
                
                Reflections reflections = new Reflections(eventHandlerPackageName);
                for(Class handlerClass : reflections.getTypesAnnotatedWith(EntityType.class))
                {
                    EntityType annotation = (EntityType) handlerClass.getAnnotation(EntityType.class);
                    if(annotation != null && annotation.value().equalsIgnoreCase(_classname))
                    //if(annotation != null)
                    {
                        Constructor constructor = handlerClass.getConstructors()[0];
                        CrudEventHandler eventHandler = (CrudEventHandler)constructor.newInstance();

                        crudEventHandlerManager.put(classname, eventHandler);

                        return crudEventHandlerManager.get(classname);
                    }
                }
                
            } catch (SecurityException | InstantiationException | IllegalAccessException | IllegalArgumentException | InvocationTargetException ex) {
                
                Logger.getLogger(CrudEventHandler.class.getName()).log(Level.SEVERE, null, ex);
            }
            
            return crudEventHandlerManager.get("core");
        }

        private void loadBaseCrudEventHandlers() 
        {
            try
            {
                Reflections reflections = new Reflections("core");
                for(Class handlerClass : reflections.getTypesAnnotatedWith(EntityType.class))
                {
                    EntityType annotation = (EntityType) handlerClass.getAnnotation(EntityType.class);
                    if(annotation != null)
                    {
                        Constructor constructor = handlerClass.getConstructors()[0];
                        CrudEventHandler eventHandler = (CrudEventHandler)constructor.newInstance();

                        crudEventHandlerManager.put("core." + annotation.value(), eventHandler);
                    }
                }
            } catch (SecurityException | InstantiationException | IllegalAccessException | IllegalArgumentException | InvocationTargetException ex) {
                
                Logger.getLogger(CrudEventHandler.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
