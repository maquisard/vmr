/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package settings;

import core.Entity;
import core.Query;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author El Zede
 */
public class Settings extends Entity 
{

    private String name;

    public Settings() 
    {
    }

    public Settings(String name)
    {
        try
        {
            if(Settings.retrieveByName(name) != null)
            {
                throw new Exception("Settings with " + name + " already exists. Settings name must be unique.");
            }
            this.name = name;
        } catch (Exception ex) {
            Logger.getLogger(Settings.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public List<SettingsProperty> retrieveProperties()
    {
        Query query;
        try 
        {
            query = new Query("SettingsProperty");
            query.filter("settingsid", this.getId());
            return query.run(SettingsProperty.class);
        
        } catch (Exception ex) {
            Logger.getLogger(Settings.class.getName()).log(Level.SEVERE, null, ex);
        }
        return new ArrayList<>();
    }
    
    public SettingsProperty addProperty(String name, String value, String type)
    {
        SettingsProperty property = new SettingsProperty(name, value, type, id);
        property.save();
        return property;
    }
    
    public SettingsProperty addProperty(String name, String value)
    {
        return this.addProperty(name, value, "");
    }
    
    public void removeProperty(SettingsProperty property)
    {
        if(property != null) property.delete();
    }
    
    protected static Settings retrieveByName(String name)
    {
        try 
        {
            Query query = new Query("Settings");
            query.filter("name", name);
            List<Settings> settings = query.run(Settings.class);
            
            if(settings.size() == 1) return settings.get(0);
            
        } catch (Exception ex) {
            Logger.getLogger(Settings.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return null;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    
}
