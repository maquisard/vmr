/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package settings;

import core.Entity;

/**
 *
 * @author El Zede
 */
public class SettingsProperty extends Entity 
{
    private String name;
    private String value;
    private String type;
    private String settingsid;

    public SettingsProperty() 
    {
        super();
    }


    public SettingsProperty(String name, String value, String type, String settingsid) 
    {
        super();
        this.name = name;
        this.value = value;
        this.type = type;
        this.settingsid = settingsid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getSettingsid() {
        return settingsid;
    }

    public void setSettingsid(String settingsid) {
        this.settingsid = settingsid;
    }    
}
