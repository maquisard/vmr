/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package settings;

import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author El Zede
 */
public abstract class CustomSettings extends Settings
{
    protected Map<String, SettingsProperty> properties = new HashMap<>();
    
    /**
     *
     */
    protected CustomSettings()
    {
        Settings settingsEntity = Settings.retrieveByName(this.settingsName());
        if(settingsEntity != null)
        {
            this.setId(settingsEntity.getId());
            this.setName(settingsEntity.getName());
            
            try 
            {
                for(SettingsProperty property : this.retrieveProperties())
                {
                    properties.put(property.getName(), property);
                }
            } catch (Exception ex) {
                Logger.getLogger(CustomSettings.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    
    
    public String getValue(String name)
    {
        return this.getProperty(name).getValue();
    }
    
    protected SettingsProperty getProperty(String name)
    {
        return properties.get(name);
    }
    
    @Override
    public SettingsProperty addProperty(String name, String value)
    {
        SettingsProperty property = super.addProperty(name, value);
        properties.put(name, property);
        return property;
    }
    
    @Override
    public void removeProperty(SettingsProperty property)
    {
        if(property != null)
        {
            super.removeProperty(property);
            properties.remove(property.getName());
        }
    }
    
    public abstract String settingsName();
}
