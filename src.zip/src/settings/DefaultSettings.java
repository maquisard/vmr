/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package settings;

/**
 *
 * @author El Zede
 */
public class DefaultSettings extends CustomSettings 
{
    private static DefaultSettings current = null;

    protected DefaultSettings()
    {
        super();
    }
    
    public static DefaultSettings getCurrent()
    {
        if(current == null)
        {
            current = new DefaultSettings();
        }
        return current;
    }
    
    @Override
    public String settingsName() 
    {
        return "default";
    }
    
    public String getUsernameProperty()
    {
        return getValue("authentication.usernameproperty");
    }
    
    public String getEntity()
    {
        return getValue("authentication.entity");
    }
    
    public String getPasswordProperty()
    {
        return getValue("authentication.passwordproperty");
    }
}
