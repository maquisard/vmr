/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package metadata;

import java.sql.Types;

/**
 *
 * @author elzede
 */
public class SQLTypeMap 
{
    
  public static String convert(int type, int size) {
    String result = "java.lang.Object";

    switch( type ) 
    {
      case Types.CHAR:
      case Types.CLOB:
      case Types.VARCHAR:
      case Types.LONGVARCHAR:
        result = "String";
        break;

      case Types.NUMERIC:
      case Types.DECIMAL:
        result = "java.math.BigDecimal";
        break;

      case Types.DATALINK:            
        result = "java.net.URL";
        break;
          
      case Types.BIT:
      case Types.BOOLEAN:
        result = "boolean";
        break;

      case Types.TINYINT:            
        result = (size == 1) ? "boolean" : "byte";
        break;

      case Types.SMALLINT:
        result = "short";
        break;

      case Types.INTEGER:
        result = "int";
        break;

      case Types.BIGINT:
        result = "long";
        break;

      case Types.FLOAT:
          result = "float";
          break;
          
      case Types.DOUBLE:
      case Types.REAL:
        result = "double";
        break;

      case Types.BINARY:
      case Types.BLOB:
      case Types.VARBINARY:
      case Types.LONGVARBINARY:
        result = "byte[]";
        break;

      case Types.DATE:
        result = "java.util.Date";
        break;

      case Types.TIME:
        result = "java.util.Time";
        break;

      case Types.TIMESTAMP:
        result = "java.util.Date";
        break;
    }

    return result;
  }
    
}
