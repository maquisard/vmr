/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package metadata;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author elzede
 */
public class DatabaseConnection 
{
    private static DatabaseConnection instance = null;
    private String server = "";
    private String database = "";
    private String username = "";
    private String password = "";
    private static boolean connected = false;
    
    private DatabaseMetadata metadata = null;
    
    private DatabaseConnection() 
    { 
    }
    
    private String generateConnectionUrl()
    {
        return String.format("jdbc:mysql://%s/%s?autoreconnect=true", server, database);
    }
    
    private void init()
    {
        try 
        {
            Class.forName("com.mysql.jdbc.Driver").newInstance();
            String connectionUrl = this.generateConnectionUrl();
            Connection connection = DriverManager.getConnection(connectionUrl, username, password);
            metadata = new DatabaseMetadata(database, connection);
            
            connected = connection.isValid(0);
            
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | SQLException ex) {
            Logger.getLogger(DatabaseConnection.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
        
    public static void create(String server, String database, String username, String password)
    {
        instance = new DatabaseConnection();
        instance.server = server;
        instance.database = database;
        instance.username = username;
        instance.password = password;
        
        instance.init();
    }
    
    
    public static boolean isValid()
    {
        return connected;
    }
    
    public static DatabaseMetadata getMetadata()
    {
        return instance.metadata;
    }
}
