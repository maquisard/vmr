/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package metadata;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author elzede
 */
public class DatabaseMetadata 
{
    private String name = "";
    private List<DatabaseTable> tables = new ArrayList<>();
    
    public DatabaseMetadata(String name, Connection connection)
    {
        this.name = name;
        if(connection != null)
        {
            try 
            {
                ResultSet set = connection.getMetaData().getTables(null, null, "%", null);
                while(set.next())
                {
                    String tableName = set.getString("TABLE_NAME");
                    DatabaseTable table = new DatabaseTable(tableName);
                    ResultSet colSet = connection.getMetaData().getColumns(null, null, tableName, null);
                    while(colSet.next())
                    {
                        DatabaseTableColumn tableColumn = new DatabaseTableColumn();
                        tableColumn.name = colSet.getString("COLUMN_NAME");
                        tableColumn.columnType = colSet.getInt("DATA_TYPE");
                        tableColumn.columnSize = colSet.getInt("COLUMN_SIZE");
                        table.columns.add(tableColumn);
                    }
                    tables.add(table);
                }
                
            } catch (SQLException ex) {
                Logger.getLogger(DatabaseMetadata.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    
    public String getName()
    {
        return name;
    }
    
    public DatabaseTable[] getTables()
    {
        return tables.toArray(new DatabaseTable[0]);
    }
    
    @Override
    public String toString()
    {
        String message = name;
        for(DatabaseTable table : tables)
        {
            message += "\n" + table.toString();
        }
        return message;
    }
    
    public class DatabaseTable 
    {
        private String name = "";
        private List<DatabaseTableColumn> columns = new ArrayList<>();
        
        private DatabaseTable(String name)
        {
            this.name = name;
        }

        public String getName()
        {
            return name;
        }
        
        public DatabaseTableColumn[] getColumns()
        {
            return columns.toArray(new DatabaseTableColumn[0]);
        }
        
        @Override
        public String toString()
        {
            String message = name;
            for(DatabaseTableColumn column : columns)
            {
                message += "\n\t" + column.toString();
            }
            return message;
        }
    }
    
    public class DatabaseTableColumn
    {
        private String name;
        private int columnType;
        private int columnSize;
        
        private DatabaseTableColumn()
        {
            
        }

        /**
         * @return the name
         */
        public String getName() 
        {
            return name;
        }
        
        public String getJavaType()
        {
            return SQLTypeMap.convert(columnType, columnSize);
        }
        
        @Override
        public String toString()
        {
            return name + "[" + getJavaType() + "]";
        }

    }
}
